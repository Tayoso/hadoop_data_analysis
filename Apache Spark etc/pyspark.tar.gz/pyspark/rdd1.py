#load sparkcontext, import packages for datetime and rdd persist
import sys
from pyspark import SparkContext
from datetime import datetime
from pyspark import StorageLevel
import time
from pyspark import SparkConf, SparkContext
conf = (SparkConf()
         .setMaster("local")
         .setAppName("My Spark App")
         .set("spark.executor.memory", "1g"))
sc = SparkContext(conf = conf)

#question1
#Load game data. Split each column. Convert the datetime string to datetime.datetime
rddg = sc.textFile("/user/training/game")
rddg1 = rddg.map(lambda line: line.split(','))
rddg2 = rddg1.map(lambda line: (line[0], line[1], line[2], datetime.strptime(line[3], "%Y-%m-%d %H:%M:%S.%f"), datetime.strptime(line[4], "%Y-%m-%d %H:%M:%S.%f"))).map(lambda (a, b, c, d, e): (a, b, c, d, e, (e-d)))

#define tweet and tweet hashtag tables
rddt = sc.textFile('/user/training/tweet', 2).map(lambda line: line.split(',')).map(lambda fields: (fields[0], (fields[1], fields[2])))
rddth = sc.textFile('/user/training/tweet_hashtag', 2).map(lambda line: line.split(',')).map(lambda fields: (fields[0], (fields[1])))
rddtth = rddt.join(rddth)

#rdds to map fc1 and fc2 as keys to prepare them for joining
rddfc1 = rddg2.map(lambda fields: (fields[1], (fields[0], fields[3], fields[4], fields[5])))
rddfc2 = rddg2.map(lambda fields: (fields[2], (fields[0], fields[3], fields[4], fields[5])))

#Rearrange tth(tweets+tweethashtag data) so field 1 1 becomes 0, pair tth(field 1 1) and fc1 using hashtag id and fcid(field 0) as key
rddtth2 = rddtth.map(lambda x: (x[1][1], (x[0], x[1][0][0], x[1][0][1])))

#join rddtth2 with rddfc1 and select distinct values
rddtth2_fc1 = rddtth2.join(rddfc1).distinct().persist(StorageLevel.DISK_ONLY)

#join rddtth2 with rddfc2 and select distinct values
rddtth2_fc2 = rddtth2.join(rddfc2).distinct().persist(StorageLevel.DISK_ONLY)

#union tth fc1 and tth fc2 using fc1 and fc2 as keyid
rddtth_fc = rddtth2_fc2.union(rddtth2_fc1)

#Transform tweet created to datetime
rddtth_fc1 = rddtth_fc.map(lambda x: (x[0], (x[1][0][0], datetime.strptime(x[1][0][1], "%Y-%m-%d %H:%M:%S.%f"), x[1][0][2]), (x[1][1][0], x[1][1][1], x[1][1][2], x[1][1][3])))

#filter the tweets between officialend and officialstart
rddtth_fc2 = rddtth_fc1.filter(lambda x: x[1][1] <= x[2][2] and x[1][1] >= x[2][1]).persist(StorageLevel.DISK_ONLY)

#Transform into game id and count of tweets
rddtth_fc3 = rddtth_fc2.map(lambda x: (x[2][0], (x[1][0]))).persist(StorageLevel.DISK_ONLY)
rddtth_fc4 = rddtth_fc3.map(lambda x: (x[0], 1)).reduceByKey(lambda a,b: a+b)

#rearrange so count of tweet id is the first column and sort by descending
rddtth_fc5 = rddtth_fc4.map(lambda x: (x[1], x[0])).sortByKey(False).persist(StorageLevel.DISK_ONLY)

#make count of tweet id key.
rddtth_fc6 = rddtth_fc5.map(lambda x: (x[0], (x[1])))

#transform into an rdd containing the game id and game minutes
rddg3 = rddg2.map(lambda (a, b, c, d, e, f): (a, (f)))

#create an rdd with game id, game minutes column and count of tweets
rddtth_fc6 = rddg3.join(rddtth_fc4)

#create an rdd that converts the game minutes column in datetime.timedelta to seconds
rddtth_fc7 = rddtth_fc6.map(lambda x: (x[0], (x[1][0].total_seconds(), x[1][1]))).persist(StorageLevel.DISK_ONLY)

#convert the seconds to minutes
rddtth_fc8 = rddtth_fc7.map(lambda x: (x[0], (x[1][0]/60, x[1][1])))

#divide the count of tweets by the game minutes,reorder the columns and sort by descending. Save the output to a text file, causing evaluation.
rdd1 = rddtth_fc8.map(lambda x: (x[0], int(x[1][1] / x[1][0]))).map(lambda (a, b): (b, a)).sortByKey(False)
rdd1.map(lambda (x, y): "{0},{1}".format(x, y)).coalesce(1).saveAsTextFile("/user/training/pyspark/1")









