#load sparkcontext, import packages for datetime and rdd persist
import sys
from pyspark import SparkContext
from datetime import datetime
from pyspark import StorageLevel
import time

sc = SparkContext()

#question1
#Load game data. Split each column. Convert the datetime string to datetime.datetime
rddg = sc.textFile("/user/training/game")
rddg1 = rddg.map(lambda line: line.split(','))
rddg2 = rddg1.map(lambda line: (line[0], line[1], line[2], datetime.strptime(line[3], "%Y-%m-%d %H:%M:%S.%f"), datetime.strptime(line[4], "%Y-%m-%d %H:%M:%S.%f"))).map(lambda (a, b, c, d, e): (a, b, c, d, e, (e-d)))

#define tweet and tweet hashtag tables
rddt = sc.textFile('/user/training/tweet', 3).map(lambda line: line.split(',')).map(lambda fields: (fields[0], (fields[1], fields[2])))
rddth = sc.textFile('/user/training/tweet_hashtag', 3).map(lambda line: line.split(',')).map(lambda fields: (fields[0], (fields[1])))
rddtth = rddt.join(rddth)

#rdds to map fc1 and fc2 as keys to prepare them for joining
rddfc1 = rddg2.map(lambda fields: (fields[1], (fields[0], fields[3], fields[4], fields[5])))
rddfc2 = rddg2.map(lambda fields: (fields[2], (fields[0], fields[3], fields[4], fields[5])))

#Rearrange tth(tweets+tweethashtag data) so field 1 1 becomes 0, pair tth(field 1 1) and fc1 using hashtag id and fcid(field 0) as key
rddtth2 = rddtth.map(lambda x: (x[1][1], (x[0], x[1][0][0], x[1][0][1])))

#join rddtth2 with rddfc1 and select distinct values
rddtth2_fc1 = rddtth2.join(rddfc1).distinct().persist(StorageLevel.DISK_ONLY)

#join rddtth2 with rddfc2 and select distinct values
rddtth2_fc2 = rddtth2.join(rddfc2).distinct().persist(StorageLevel.DISK_ONLY)

#union tth fc1 and tth fc2 using fc1 and fc2 as keyid
rddtth_fc = rddtth2_fc2.union(rddtth2_fc1)

#Transform tweet created to datetime
rddtth_fc1 = rddtth_fc.map(lambda x: (x[0], (x[1][0][0], datetime.strptime(x[1][0][1], "%Y-%m-%d %H:%M:%S.%f"), x[1][0][2]), (x[1][1][0], x[1][1][1], x[1][1][2], x[1][1][3])))

#filter the tweets between officialend and officialstart
rddtth_fc2 = rddtth_fc1.filter(lambda x: x[1][1] <= x[2][2] and x[1][1] >= x[2][1]).persist(StorageLevel.DISK_ONLY)

#Transform into game id and count of tweets
rddtth_fc3 = rddtth_fc2.map(lambda x: (x[2][0], (x[1][0]))).persist(StorageLevel.DISK_ONLY)
rddtth_fc4 = rddtth_fc3.map(lambda x: (x[0], 1)).reduceByKey(lambda a,b: a+b)

#rearrange so count of tweet id is the first column and sort by descending
rddtth_fc5 = rddtth_fc4.map(lambda x: (x[1], x[0])).sortByKey(False).persist(StorageLevel.DISK_ONLY)

#make count of tweet id key.
rddtth_fc6 = rddtth_fc5.map(lambda x: (x[0], (x[1])))

#transform into an rdd containing the game id and game minutes
rddg3 = rddg2.map(lambda (a, b, c, d, e, f): (a, (f)))

#create an rdd with game id, game minutes column and count of tweets
rddtth_fc6 = rddg3.join(rddtth_fc4)

#create an rdd that converts the game minutes column in datetime.timedelta to seconds
rddtth_fc7 = rddtth_fc6.map(lambda x: (x[0], (x[1][0].total_seconds(), x[1][1]))).persist(StorageLevel.DISK_ONLY)

#convert the seconds to minutes
rddtth_fc8 = rddtth_fc7.map(lambda x: (x[0], (x[1][0]/60, x[1][1])))

#divide the count of tweets by the game minutes,reorder the columns and sort by descending. Save the output to a text file, causing evaluation.
rdd1 = rddtth_fc8.map(lambda x: (x[0], (x[1][1] / x[1][0]))).map(lambda (a, b): (b, a)).sortByKey(False)
rdd1.saveAsTextFile("ans1pyspark")

#question2
#map the game id and the user id, count the number of distinct users
game_user = rddtth_fc2.map(lambda x: (x[2][0], (x[1][2])))
game_user2 = game_user.distinct().map(lambda x: (x[0], 1)).reduceByKey(lambda a,b: a+b)
game_user2.persist(StorageLevel.DISK_ONLY)

#reorder the columns so count of user id is key and sort by descending for top 10 games with most distinct user ids
game_user3 = game_user2.map(lambda x: (x[1], x[0])).sortByKey(False).take(10)
game_user3.saveAsTextFile("ans2pyspark")

#question3
#map to reorder columns as game id and count of tweets
tweets_during_game = rddtth_fc8.map(lambda (a, (b, c)): (c, (a))).sortByKey(False).map(lambda (a, b): (b, (a)))

#join the fc1 and fc2 data
game_fc = rddfc1.join(rddfc2)

#Reorder the columns to make fc key, 2 games they played as values
game_fc2 = game_fc.map(lambda x: (x[0], (x[1][0][0], x[1][1][0])))
rddg2_keyRDD = rddg2.map(lambda (a, b, c, d, e, (f)): (a, (b, c, d, e, f)))

#join the rdds with the count of tweets during game and game data above
game_fc3 = tweets_during_game.join(rddg2_keyRDD).sortByKey(False)

#map game_fc3 to select fc1 and fc2 as key, game id and count tweets as values and union them
game_fc4 = game_fc3.map(lambda (a, (b, (c, d, e, f, g))): (a, b, c, d)).map(lambda (a, b, c, d): (c, (a, b)))
game_fc5 = game_fc3.map(lambda (a, (b, (c, d, e, f, g))): (a, b, c, d)).map(lambda (a, b, c, d): (d, (a, b)))
game_fc6 = game_fc4.union(game_fc5)

#Count the number of games each fc has, rearrange the column to sort by the highest number of games
game_fc7 = game_fc6.map(lambda x: (x[0], 1)).reduceByKey(lambda a,b: a+b).map(lambda (a, b): (b, a)).sortByKey(False)

#Rearrange the game_fc7 column to make available for joining with game_fc6
game_fc8 = game_fc7.map(lambda (a, b): (b, (a))).join(game_fc6).persist(StorageLevel.DISK_ONLY)

#map to reorder columns to select the fc with the most games, '5'
game_fc9 = game_fc8.map(lambda (a, (b)): (b, (a))).sortByKey(False)
game_fc10 = game_fc9.map(lambda ((a, (b, c)), d): (d, (b, c, a))).filter(lambda x: x[1][2] >= 5)

#select the columns containing the count of tweets and fc, sort by the count of tweets and top 3 game id
game_fc11 = game_fc10.map(lambda (a, (b, c, d)): (c, (a))).sortByKey(False).map(lambda (a, b): (b, (a))).persist(StorageLevel.DISK_ONLY)
game_fc12 = game_fc11.map(lambda (a, b): (b, (str(a)))).sortByKey(False).map(lambda (a, b): (b, a)).reduceByKey(max).map(lambda (a, b): (b, a)).sortByKey(False).take(3)
game_user12.saveAsTextFile("ans3pyspark")

#question4
#create an rdd that converts the tweet created, officialend and officialend - 600seconds to seconds
tweets1 = rddtth_fc2.map(lambda x: (x[2][0], (x[1][0], time.mktime(x[1][1].timetuple()), time.mktime(x[2][2].timetuple())))).map(lambda x: (x[0], (x[1][0], x[1][1], x[1][2], x[1][2]-600))).distinct()

#find the tweets between officialend and officialend-600seconds
tweets2 = tweets1.filter(lambda x: x[1][1] <= x[1][2] and x[1][1] >= x[1][3])

#map the game id and the tweet id, count the number of tweets
tweets3 = tweets2.map(lambda x: (x[0], (x[1][0]))).map(lambda x: (x[0], 1)).reduceByKey(lambda a,b: a+b).persist(StorageLevel.DISK_ONLY)

#rearrange so count of tweet id is the first column and sort by descending
tweets4 = tweets3.map(lambda x: (x[1], x[0])).sortByKey(False).take(10)

#count of tweets,game.id
tweets4.saveAsTextFile("ans4pyspark")

#question5
#make the pair rdds identical so as to remove the official hashtags from total hashtags
tweets5 = rddtth_fc2.map(lambda (a, (b, c, d), (e, f, g, h)): (a, (b, c, d)))
tweets6 = rddtth.map(lambda line: (line[0], ((datetime.strptime(line[1][0][0], "%Y-%m-%d %H:%M:%S.%f"), line[1][0][1]), line[1][1]))).map(lambda (a, ((b, c), d)): (d, (a, b, c)))
#extract the data belonging to non official hashtags
tweets7 = tweets6.subtractByKey(tweets5)
tweets7.persist(StorageLevel.DISK_ONLY)

#map the hashtag id and the tweet created time, count the number of hashtags
tweets8 = tweets7.map(lambda x: (x[0], (x[1][1]))).map(lambda x: (x[0], 1)).reduceByKey(lambda a,b: a+b)
tweets8.persist(StorageLevel.DISK_ONLY)

#reorder columns so count of hashtag id is key and sort by descending. Select top 10 non official hashtags
tweets9 = tweets8.map(lambda x: (x[1], x[0])).sortByKey(False).take(10)
tweets9.saveAsTextFile("ans5pyspark")

#question6
#Select tweets from game 36. Filter the tweets created btw os and oe and in game 36. convert the time to hour and minute format and count the tweets per minute
game36_1 = rddtth_fc2.filter(lambda x: x[2][0] == '36').map(lambda x: (x[1][0], (time.mktime(x[1][1].timetuple()), time.mktime(x[2][1].timetuple()), time.mktime(x[2][2].timetuple())))).persist(StorageLevel.DISK_ONLY)
rdd6_1 = game36_1.map(lambda x: (x[0], int(x[1][0]), int(x[1][1]), int(x[1][2]))).filter(lambda x: x[2] <= x[1] <= x[3])
rdd6 = rdd6_1.map(lambda x: (x[1], 1)).map(lambda x: (datetime.fromtimestamp(x[0]).strftime("%H:%M"), x[1])).reduceByKey(lambda a,b: a+b).sortByKey(True)

rdd6.saveAsTextFile("ans6pyspark")

sc.stop()









