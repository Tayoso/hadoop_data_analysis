mkdir /home/training/alpha/pyspark_answers

mkdir /home/training/alpha/pyspark_answers/1/
mkdir /home/training/alpha/pyspark_answers/2/
mkdir /home/training/alpha/pyspark_answers/3/
mkdir /home/training/alpha/pyspark_answers/4/
mkdir /home/training/alpha/pyspark_answers/5/
mkdir /home/training/alpha/pyspark_answers/6/

cd /home/training/alpha/pyspark

#answers questions 1-6 in pyspark..move the answers from hdfs to local filesystem
spark-submit --master local[4] --master yarn-client rdd1.py /home/training/alpha/pyspark/rdd1.py
hdfs dfs -get /user/training/pyspark/1/part* /home/training/alpha/pyspark_answers/1/

spark-submit --master local[4] --master yarn-client rdd2.py /home/training/alpha/pyspark/rdd2.py
hdfs dfs -get /user/training/pyspark/2/part* /home/training/alpha/pyspark_answers/2/

spark-submit --master local[4] --master yarn-client rdd3.py /home/training/alpha/pyspark/rdd3.py
hdfs dfs -get /user/training/pyspark/3/part* /home/training/alpha/pyspark_answers/3/

spark-submit --master local[4] --master yarn-client rdd4.py /home/training/alpha/pyspark/rdd4.py
hdfs dfs -get /user/training/pyspark/4/part* /home/training/alpha/pyspark_answers/4/

spark-submit --master local[4] --master yarn-client rdd5.py /home/training/alpha/pyspark/rdd5.py
hdfs dfs -get /user/training/pyspark/5/part* /home/training/alpha/pyspark_answers/5/

spark-submit --master local[4] --master yarn-client rdd6.py /home/training/alpha/pyspark/rdd6.py
hdfs dfs -get /user/training/pyspark/6/part* /home/training/alpha/pyspark_answers/6/



