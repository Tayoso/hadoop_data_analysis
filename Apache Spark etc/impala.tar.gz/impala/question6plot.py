from matplotlib import pyplot as plt
import pandas as pd
 
df = pd.read_csv('/home/training/alpha/impala_answers/6.csv',header = None)
Minutes = df.iloc[:,0]
Tweets = df.iloc[:,1]
plt.plot(Minutes,Tweets)
plt.xticks(rotation=90)
plt.title('Tweets during Arsenal vs Manchester United')
plt.ylabel('Tweets')
plt.xlabel('Minutes')

plt.show()

