invalidate METADATA;

--drop views so as not to interrupt hive processing

drop table fc;
drop table game;
drop table game_goals;
drop table tweet;
drop table tweet_hashtag;
drop table hashtag;
drop table hashtag_fc;
drop view avg_tweets_per_game_minute;
drop view distinct_users_tweet_game;
drop view from_game;
drop view from_tweet;
drop view game_tweets_created;
drop view games_per_club;
drop view hashtags_count_during_game;
drop view list_tweets;
drop view list_tweets_in_game36;
drop view new_game;
drop view tweets_official_hashtags;
drop view top3_games_tweets_per_club;
drop view tweet_otherhashtags;
drop view total_tweets_per_game;
drop view tt_h;
drop view tweets_last10mins_game;
drop view tweets_per_game;
drop view tweets_per_minute_game36;
drop view tweets_per_minute_game21;
drop view tweets_per_minute_game8;



