invalidate METADATA;

--EXTRA: Count of hashtags used during game
create view hashtags_count_during_game as
select t.hashtag_id,COUNT(t.hashtag_id) as hashtag_count
from game g,tt_h t
where t.created between g.officialstart and g.officialend and t.hashtag_id = g.fc1
or t.hashtag_id = g.fc2 and t.created between g.officialstart and g.officialend
group by t.hashtag_id
order by hashtag_count DESC;

select hashtag_id,hashtag_count
from hashtags_count_during_game
order by hashtag_count DESC;

