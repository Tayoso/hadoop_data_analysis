invalidate METADATA;

--Game 36 which was between Arsenal and Manchester United had the highest number of average tweets per game minute in question 1

create view list_tweets_in_game36 as
select t.id,t.created,g.id as game_id
from game g,tt_h t
where t.created between g.officialstart and g.officialend and g.id = 36 and t.hashtag_id = g.fc1 
or t.hashtag_id = g.fc2 and g.id = 36 and t.created between g.officialstart and g.officialend;

create view tweets_per_minute_game36 as
select substr(created, 12, 5) as Game_minutes,count(id) as Tweets
from list_tweets_in_game36
group by Game_minutes;

select Game_minutes,Tweets
from tweets_per_minute_game36
order by Game_minutes ASC;



