invalidate METADATA;

--Convert the string in date to unix timestamp. Calculate amount of game minutes from game table 
create view new_game as
select id,fc1,fc2,(unix_timestamp(officialend) - unix_timestamp(officialstart))/60 as game_minutes    
from game;

--Join tables tweet and tweethashtag on tweet.id
create view tt_h as
select t.id,t.created,t.user_id,h.hashtag_id
from tweet t,tweet_hashtag h
where t.id = h.tweet_id;

--count distinct tweets in each game, order by top 10
create view tweets_per_game as
select g.id,count(distinct t.id) as no_tweets
from game g,tt_h t
where t.created between g.officialstart and g.officialend and t.hashtag_id = g.fc1
or t.hashtag_id = g.fc2 and t.created between g.officialstart and g.officialend
group by g.id
order by no_tweets DESC LIMIT 10;

--calculate average tweets per game
create view avg_tweets_per_game_minute as
select t.id,cast(t.no_tweets / n.game_minutes as DECIMAL(6,0)) as avg_tweets
from tweets_per_game t,new_game n
where t.id = n.id
order by avg_tweets DESC;

select id,avg_tweets
from avg_tweets_per_game_minute;
