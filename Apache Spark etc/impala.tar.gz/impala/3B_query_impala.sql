invalidate METADATA;

--count distinct tweets per game
create view total_tweets_per_game as
select g.id,g.fc1,g.fc2,COUNT(distinct t.id) as no_tweets
from game g,tt_h t
where t.created between g.officialstart and g.officialend and t.hashtag_id = g.fc1
or t.hashtag_id = g.fc2 and t.created between g.officialstart and g.officialend
group by g.id,g.fc1,g.fc2
order by no_tweets DESC;

--Teams that played in most games
create view games_per_club as
Select f.id,count(f.id) as counting
From fc f,game g
Where f.id = g.fc1 or f.id = g.fc2
group by f.id
order by counting;

--Top 3 games tweets by club
create view top3_games_tweets_per_club as
select c.id,t.no_tweets
from games_per_club c,total_tweets_per_game t
where c.id = t.fc1 and c.counting = 5 OR c.id = t.fc2 and c.counting = 5
group by c.id,t.no_tweets
order by t.no_tweets DESC;

select distinct(id),no_tweets
from top3_games_tweets_per_club
order by no_tweets DESC LIMIT 3;
