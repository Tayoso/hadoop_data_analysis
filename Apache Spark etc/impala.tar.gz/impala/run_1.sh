mkdir /home/training/alpha/impala_answers
cd /home/training/alpha/impala
impala-shell -B -f 1B_query_impala.sql -o /home/training/alpha/impala_answers/1.csv --print_header '--output_delimiter=,'
impala-shell -B -f 2B_query_impala.sql -o /home/training/alpha/impala_answers/2.csv --print_header '--output_delimiter=,'
impala-shell -B -f 3B_query_impala.sql -o /home/training/alpha/impala_answers/3.csv --print_header '--output_delimiter=,'
impala-shell -B -f 4B_query_impala.sql -o /home/training/alpha/impala_answers/4.csv --print_header '--output_delimiter=,'
impala-shell -B -f 5B_query_impala.sql -o /home/training/alpha/impala_answers/5.csv --print_header '--output_delimiter=,'
impala-shell -B -f 6B_query_impala.sql -o /home/training/alpha/impala_answers/6.csv '--output_delimiter=,'

#Further analysis to find trend of tweet spikes during games
impala-shell -B -f 7B_query_impala.sql -o /home/training/alpha/impala_answers/7.csv --print_header '--output_delimiter=,'
impala-shell -B -f 8B_query_impala.sql -o /home/training/alpha/impala_answers/8.csv --print_header '--output_delimiter=,'

#Further analysis to find count of hashtags during game. 
impala-shell -B -f 9B_query_impala.sql -o /home/training/alpha/impala_answers/9.csv --print_header '--output_delimiter=,'

#visualize the python script
/usr/local/bin/python2.7 /home/training/alpha/impala/question6plot.py

impala-shell -f drop_impala_views.sql



