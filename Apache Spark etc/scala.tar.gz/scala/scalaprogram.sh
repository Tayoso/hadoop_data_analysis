mkdir /home/training/alpha/scala_answers


mkdir /home/training/alpha/scala_answers/1/
mkdir /home/training/alpha/scala_answers/2/
mkdir /home/training/alpha/scala_answers/3/
mkdir /home/training/alpha/scala_answers/4/
mkdir /home/training/alpha/scala_answers/5/
mkdir /home/training/alpha/scala_answers/6/

hdfs dfs -get /user/training/scala/1/part* /home/training/alpha/scala_answers/1/

hdfs dfs -get /user/training/scala/2/part* /home/training/alpha/scala_answers/2/

hdfs dfs -get /user/training/scala/3/part* /home/training/alpha/scala_answers/3/

hdfs dfs -get /user/training/scala/4/part* /home/training/alpha/scala_answers/4/

hdfs dfs -get /user/training/scala/5/part* /home/training/alpha/scala_answers/5/

hdfs dfs -get /user/training/scala/6/part* /home/training/alpha/scala_answers/6/
