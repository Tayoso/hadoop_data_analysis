--Convert the date(string) to timestamps
create view from_tweet as
select id,user_id,unix_timestamp(created) as created
from tweet;

create view from_game as
select id,fc1,fc2,unix_timestamp(officialend) as officialend,(unix_timestamp(officialend) - 600) as last_10mins
from game;

--list official tweets created during game
Create view list_tweets as
select distinct(t.id)
from game g,tt_h t
where t.created between g.officialstart and g.officialend and t.hashtag_id = g.fc1
or t.hashtag_id = g.fc2 and t.created between g.officialstart and g.officialend;

create view game_tweets_created as
select f.id,f.user_id,f.created
from from_tweet f,list_tweets t
where f.id = t.id;

--count tweets created in last 10 minutes of games. sort by descending
create view tweets_last10mins_game as
select g.id as game_id,COUNT(c.id) as counts
from from_game g,game_tweets_created c
where c.created between g.last_10mins and g.officialend
group by g.id
order by counts DESC LIMIT 10;

create table hive_4 as
select concat(game_id,',',counts)
from tweets_last10mins_game;
