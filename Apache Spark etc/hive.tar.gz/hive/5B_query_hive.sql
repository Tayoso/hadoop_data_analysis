--query to find tweets with official hashtags
create view tweets_official_hashtags as
select t.id,t.hashtag_id,COUNT(t.hashtag_id) as hashtag_count
from game g,tt_h t
where t.created between g.officialstart and g.officialend and t.hashtag_id = g.fc1
or t.hashtag_id = g.fc2 and t.created between g.officialstart and g.officialend
group by t.id;

--query to find tweets with both official and unofficial hashtags but selecting only non-official
create view tweet_otherhashtags as
select t.hashtag_id,COUNT(t.hashtag_id) as hashtag_count
from tt_h t,tweets_official_hashtags h
where t.id = h.id and t.hashtag_id NOT BETWEEN 3 and 22   
group by t.hashtag_id
order by hashtag_count DESC LIMIT 10;


create table hive_5 as
select concat(hashtag_id,',',hashtag_count)
from tweet_otherhashtags;
