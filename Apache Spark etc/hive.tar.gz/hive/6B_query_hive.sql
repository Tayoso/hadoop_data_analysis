--Game 36 which was between Arsenal and Manchester United had the highest number of average tweets per game minute in question 1. group the tweets by hour and minute

create view list_tweets_in_game36 as
select t.id,t.created,g.id as game_id
from game g,tt_h t
where t.created between g.officialstart and g.officialend and g.id = 36 and t.hashtag_id = g.fc1 
or t.hashtag_id = g.fc2 and g.id = 36 and t.created between g.officialstart and g.officialend;

create view tweets_per_minute_game36 as
select concat(cast(hour(created) AS STRING),':',LPAD(cast(minute(created) AS STRING), 2, '0')) as Game_minutes,count(id) as Tweets
from list_tweets_in_game36
group by hour(created),minute(created)
order by Game_minutes ASC;

create table hive_6 as
select concat(Game_minutes,',',Tweets)
from tweets_per_minute_game36;




