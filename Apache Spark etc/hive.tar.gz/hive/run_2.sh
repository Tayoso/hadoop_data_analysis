mkdir /home/training/alpha/hive_answers
cd /home/training/alpha/hive

#start the Hive Server using these commands
sudo service zookeeper-server start
sudo service hive-server2 start
#start the Hive Server using these commands
sudo service zookeeper-server start
sudo service hive-server2 start

#import tables from mysql to hive
sqoop import-all-tables --connect jdbc:mysql://localhost/alpha --username training --password training --fields-terminated-by ',' --hive-import --warehouse-dir /user/hive/warehouse

hive -f 1B_query_hive.sql
hdfs dfs -get /user/hive/warehouse/hive_1/* /home/training/alpha/hive_answers/1.csv 

hive -f 2B_query_hive.sql
hdfs dfs -get /user/hive/warehouse/hive_2/* /home/training/alpha/hive_answers/2.csv 

hive -f 3B_query_hive.sql
hdfs dfs -get /user/hive/warehouse/hive_3/* /home/training/alpha/hive_answers/3.csv 

hive -f 4B_query_hive.sql
hdfs dfs -get /user/hive/warehouse/hive_4/* /home/training/alpha/hive_answers/4.csv 

hive -f 5B_query_hive.sql 
hdfs dfs -get /user/hive/warehouse/hive_5/* /home/training/alpha/hive_answers/5.csv 

hive -f 6B_query_hive.sql
hdfs dfs -get /user/hive/warehouse/hive_6/* /home/training/alpha/hive_answers/6.csv 

