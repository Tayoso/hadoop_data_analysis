--select the top 10 games by distinct users tweeting during game
create view distinct_users_tweet_game as
select g.id,COUNT(DISTINCT t.user_id) as no_distinct_users
from game g,tt_h t
where t.created between g.officialstart and g.officialend and t.hashtag_id = g.fc1
or t.hashtag_id = g.fc2 and t.created between g.officialstart and g.officialend
group by g.id
order by no_distinct_users DESC LIMIT 10;

create table hive_2 as
select concat(id,',',no_distinct_users)
from distinct_users_tweet_game;

