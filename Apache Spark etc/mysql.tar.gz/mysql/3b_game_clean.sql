Update game
Set officialend = '2017-11-26 15:50:00'
where id = 17;

