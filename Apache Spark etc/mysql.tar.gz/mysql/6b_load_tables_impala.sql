invalidate metadata;
invalidate metadata;
invalidate metadata;
invalidate metadata;


Create external table if not exists fc
	(id int,
	name varchar
	)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
Location '/user/impala/fc';


Create external table if not exists game
	(id int,
	fc1 int,
	fc2 int,
	officialstart string,
	officialend string,
	halftimestart string,
	halftimeend string
	)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
Location '/user/impala/game';

Create external table if not exists tweet
	(id bigint,
	created string,
	user_id bigint
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
Location '/user/impala/tweet';

Create external table if not exists tweet_hashtag(
	tweet_id bigint,
	hashtag_id int
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
Location '/user/impala/tweet_hashtag';


Create external table if not exists hashtag(
	id int,
	hashtag varchar
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
Location '/user/impala/hashtag';


Create external table if not exists game_goals(
	game_id int,
	time string,
	fc int
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
Location '/user/impala/game_goals';


Create external table if not exists hashtag_fc(
	hashtag_id int,
	fc_id int
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
Location '/user/impala/hashtag_fc';
