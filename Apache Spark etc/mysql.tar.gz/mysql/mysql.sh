#change to working directory
cd /home/training/alpha/mysql

#create database alpha
echo 'CREATE DATABASE alpha;' | mysql -uroot
echo "GRANT USAGE on alpha.* TO training@localhost IDENTIFIED BY 'training';" | mysql -uroot 
echo "GRANT ALL PRIVILEGES ON alpha.* TO training@localhost;" | mysql -uroot 

#transfer the database in local filesystem to mysql
mysql -u "training" "-ptraining" "alpha" < "alpha.sql"

#clean game table
mysql -u "training" "-ptraining" "alpha" < "3b_game_clean.sql"

#start impala
sudo service impala-state-store start
sudo service impala-catalog start
sudo service impala-server start

#import all tables from mysql to HDFS
sqoop import-all-tables --connect jdbc:mysql://localhost/alpha --username training --password training

#start impala
sudo service impala-state-store start
sudo service impala-catalog start
sudo service impala-server start

#be sure its started
sudo service impala-state-store start
sudo service impala-catalog start
sudo service impala-server start

#create directory to store impala data
hdfs dfs -mkdir /user/impala
#make directories for impala tables
hdfs dfs -mkdir /user/impala/fc/
hdfs dfs -mkdir /user/impala/tweet/
hdfs dfs -mkdir /user/impala/game/
hdfs dfs -mkdir /user/impala/tweet_hashtag/
hdfs dfs -mkdir /user/impala/hashtag/
hdfs dfs -mkdir /user/impala/game_goals/
hdfs dfs -mkdir /user/impala/hashtag_fc/

#load tables with data
impala-shell -f 6b_load_tables_impala.sql 

hdfs dfs -cp /user/training/fc/* /user/impala/fc/
hdfs dfs -cp /user/training/tweet/* /user/impala/tweet/
hdfs dfs -cp /user/training/game/* /user/impala/game/
hdfs dfs -cp /user/training/tweet_hashtag/* /user/impala/tweet_hashtag/
hdfs dfs -cp /user/training/hashtag/* /user/impala/hashtag/
hdfs dfs -cp /user/training/game_goals/* /user/impala/game_goals/
hdfs dfs -cp /user/training/hashtag_fc/* /user/impala/hashtag_fc/
